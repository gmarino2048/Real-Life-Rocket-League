module.exports = {
  write : function(results, options, done) {
    done();
  }
};