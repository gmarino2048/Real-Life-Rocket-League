module.exports = {
  elements: [
    { someElement: '#element' },
    { otherElement: '#otherElement' }
  ]
};
