module.exports = {
  elements : {
    myElement : { selector: '.myElement' }
  }
};